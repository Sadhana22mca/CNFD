package com.example.LabCycle05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabCycle05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
