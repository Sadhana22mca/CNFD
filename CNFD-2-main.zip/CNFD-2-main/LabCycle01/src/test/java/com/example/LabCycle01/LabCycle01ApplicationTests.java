package com.example.LabCycle01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabCycle01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
