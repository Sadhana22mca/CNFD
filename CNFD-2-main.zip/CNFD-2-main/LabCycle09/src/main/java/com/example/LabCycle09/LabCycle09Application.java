package com.example.LabCycle09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabCycle09Application {

	public static void main(String[] args) {
		SpringApplication.run(LabCycle09Application.class, args);
	}

}
